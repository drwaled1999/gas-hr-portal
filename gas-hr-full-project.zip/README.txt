
GAS HR Portal Full Demo

Run locally:

1. Install Node.js
2. Run:
   npm install
   npm start

Open:
http://localhost:3000
