
const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database("./database/hr.db");

db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS employees(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    project TEXT,
    leave_total INTEGER,
    leave_used INTEGER
  )`);
});

app.get("/api/employees",(req,res)=>{
  db.all("SELECT * FROM employees",(err,rows)=>{
    res.json(rows);
  });
});

app.post("/api/employees",(req,res)=>{
  const {name,project,leave_total,leave_used}=req.body;
  db.run("INSERT INTO employees(name,project,leave_total,leave_used) VALUES(?,?,?,?)",
  [name,project,leave_total,leave_used],function(err){
    res.json({id:this.lastID});
  });
});

app.use(express.static(path.join(__dirname,"../public")));

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"../public/index.html"));
});

app.listen(3000,()=>{
  console.log("Server running on port 3000");
});
